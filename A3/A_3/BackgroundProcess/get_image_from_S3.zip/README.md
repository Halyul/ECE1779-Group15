# get_image_from_S3 - used for displaying shared image

# setup process
1. goto Lambda, click 'Create function'
2. choose 'Author from scratch'
3. enter function name (get_image_from_S3 this case), and choose 'Python 3.9' as Runtime
4. 