bucket_name = '1779-week-6-exercises-bucket'

# used for tagging
api_key = 'acc_9b89f2712ed64d1'
api_secret = '9d4847cfd72796171f078ba5e71e7121'

# shared URL API Gateway
api_gateway_url = 'https://540efic3sk.execute-api.us-east-1.amazonaws.com/dev/'